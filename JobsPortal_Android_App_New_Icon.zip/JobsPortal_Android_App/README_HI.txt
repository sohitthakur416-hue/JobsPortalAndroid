JobsPortal Android App - Android Studio Project

यह Android app आपके मौजूदा JobsPortal live website को Android WebView के अंदर खोलती है।
इसमें अलग नया backend नहीं बनाया गया है; वेबसाइट का मौजूदा Supabase/Auth/Admin सिस्टम ही इस्तेमाल होगा।

APK बनाने के लिए:
1. Android Studio इंस्टॉल करें।
2. इस ZIP को Extract करें।
3. Android Studio में Extract किया हुआ JobsPortal_Android_App फोल्डर Open करें।
4. Gradle Sync पूरा होने दें और जरूरत पड़ने पर Android SDK 35 इंस्टॉल करें।
5. Build > Build Bundle(s) / APK(s) > Build APK(s) चुनें।
6. APK app/build/outputs/apk/debug/app-debug.apk में मिलेगी।

ध्यान दें:
- App इंटरनेट कनेक्शन के साथ काम करती है।
- App अभी https://jobsportalin.netlify.app/ खोलती है।
- वेबसाइट पर उपलब्ध features और Supabase permissions के अनुसार ही Jobs/Admin सुविधाएँ काम करेंगी।
- यह Android Studio source project है, compiled APK नहीं। इस environment में Android SDK/Gradle build setup उपलब्ध नहीं था, इसलिए APK binary compile नहीं की जा सकी।
